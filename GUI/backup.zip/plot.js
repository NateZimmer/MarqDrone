var myArray = [];
var gyroArray = [];
var magArray = [];
var plotLength = 100;
var acc_options;
var samples=100;
var gsamples=100;
var msamples=100;

acc_options = {
	title: "Acc (G/s)",
	shadowSize: 0,
	yaxis: {
		max: 1.2,
		min: -1.2
	},
	xaxis: {
		//noTicks = 0
	},
	grid: {
		backgroundColor: "#FFFFFF"
	},
	legend: {
		position: "wn",
		backgroundOpacity: 0
	}
}

gyro_options = {
	title: "Gyro (G/s)",
	shadowSize: 0,
	yaxis: {
		max: 260,
		min: -260
	},
	xaxis: {
		//noTicks = 0
	},
	grid: {
		backgroundColor: "#FFFFFF"
	},
	legend: {
		position: "wn",
		backgroundOpacity: 0
	}
}

mag_options = {
	title: "Mag (G/s)",
	shadowSize: 0,
	yaxis: {
		max: 700,
		min: -700
	},
	xaxis: {
		//noTicks = 0
	},
	grid: {
		backgroundColor: "#FFFFFF"
	},
	legend: {
		position: "wn",
		backgroundOpacity: 0
	}
}

function updatePlot(ID,myArrays,kx,ky,kz,options,sample)
{
	myArrays[0].push([sample,kx]);
	myArrays[1].push([sample,ky]);
	myArrays[2].push([sample,kz]);
	
	while (myArrays[0].length > plotLength) {            
		myArrays[0].shift();
		myArrays[1].shift();
		myArrays[2].shift();
	}
	
	Flotr.draw(ID, [ 
	{data: myArrays[0], label: "X"}, 
	{data: myArrays[1], label: "Y"}, 
	{data: myArrays[2], label: "Z"} ], options);  
}

function generatePlot(myArrays,ID,options) {

        var
          start = (new Date).getTime(),
          data, graph, offset, i;
	
	myArrays[0]=[];
	myArrays[1]=[];
	myArrays[2]=[]; 

	for (var i = 0; i <= plotLength; i++) { 
		myArrays[0].push([i,0]);
		myArrays[1].push([i,0]);
		myArrays[2].push([i,0]); 
    }
	
	Flotr.draw(ID, [ 
	{data: myArrays[0], label: "X"}, 
	{data: myArrays[1], label: "Y"}, 
	{data: myArrays[2], label: "Z"} ], options);  	
        	
}

generatePlot(myArray,myPlot,acc_options);
generatePlot(gyroArray,gyroP,gyro_options);
generatePlot(magArray,magP,mag_options);