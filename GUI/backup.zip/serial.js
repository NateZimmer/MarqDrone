function addSelects()
{
	var x = document.getElementById("portPath");
	var option = document.createElement("option");
	chrome.serial.getDevices(function(ports) {
		 for (var i = 0; i < ports.length; i++) {
			 var option = document.createElement("option");
			 option.text = ports[i].path;
			 x.add(option);
		 }
	});

}
addSelects();

var ConnectionData;

var _options = {
  bitrate: 115200,
};

var isConnected=false;

var str2ab = function(str) {
  var encodedString = unescape(encodeURIComponent(str));
  var bytes = new Uint8Array(encodedString.length);
  for (var i = 0; i < encodedString.length; ++i) {
    bytes[i] = encodedString.charCodeAt(i);
  }
  return bytes.buffer;
};

var ab2str = function(buf) {
  var bufView = new Uint8Array(buf);
  var encodedString = String.fromCharCode.apply(null, bufView);
  return decodeURIComponent(escape(encodedString));
};

function onConnect(connectionInfo)
{
	ConnectionData = connectionInfo;
	console.log("Callback function");
	console.log(ConnectionData);
	if(ConnectionData.connectionId>0)
	{
		document.getElementById("connect").innerHTML="Disconnect";
		chrome.serial.onReceive.addListener(getData);
		isConnected=true;
	}
}

var lines='';
var serialLogging=false;

$('#logSerialCheck').on('change', function(){
	if(logSerialCheck.checked)
	{
		serialLogging=true;
	}
	else
	{
		serialLogging=false;
	}
});

function getData(recievedInfo)
{
	//console.log(recievedInfo);
	var inputString="";
	inputString = ab2str(recievedInfo.data); 
	lines+=inputString;
	handleLogging(inputString);
	while((index =lines.indexOf('\n'))>0)
	{
		var line = lines.substr(0,index+1);
		lines=lines.substr(index+1);
		parseLines(line);
	}
}

function handleLogging(inputData)
{
	if(serialLogging)
	{
		RecievedData +=inputData;
		$("#textBox").val(RecievedData); // This updates the text box
		textBox.scrollTop = textBox.scrollHeight;
	}
}

function parseLines(inputStrings)
{
	//console.log("Recieved Line: "+inputStrings);
	var index;
	if(inputStrings.indexOf("ACC,")>=0)
	{
		handleAcc(inputStrings);
	}
	if(inputStrings.indexOf("GYRO,")>=0)
	{
		handleGyro(inputStrings);
	}
	if(inputStrings.indexOf("MAG,")>=0)
	{
		handleMag(inputStrings);
	}
}

var ax,ay,az;

function handleAcc(inputStrings)
{
	newArray=inputStrings.split(',');
	ax=parseFloat(newArray[1]);
	ay=parseFloat(newArray[2]);
	az=parseFloat(newArray[3]);
	pitch = getPitch(ax,ay,az);
	roll = getRoll(ax,ay,az);
	//console.log("Pitch: "+ pitch);
	//console.log("Roll: "+ roll);
	document.getElementById("AccV").style.transform = myTranslate+" rotateX("+pitch+"deg) rotateY("+0+"deg) rotateZ("+roll+"deg)";
	updatePlot(myPlot,myArray,ax,ay,az,acc_options,samples);
}

var gx,gy,gz;
var gxp=0.01;
var gyp=0.01;
var gzp=0.01;

var ggain = 1;

function handleGyro(inputStrings)
{
	gyroRaw=inputStrings.split(',');
	gx=parseFloat(gyroRaw[1]);
	gy=parseFloat(gyroRaw[2]);
	gz=parseFloat(gyroRaw[3]);
	
	gxp=gxp*0.999+0.05*gx;
	gyp=gyp*0.999+0.05*gy;
	
	gxn = -1*gxp;
	gyn = -1*gyp;
	
	document.getElementById("GyroV").style.transform = myTranslate+" rotateX("+gyn+"deg) rotateY("+0+"deg) rotateZ("+gxn+"deg)";
	updatePlot(gyroP,gyroArray,gx,gy,gz,gyro_options,gsamples);
}

var mx,my,mz;

function handleMag(inputStrings)
{
	magRaw=inputStrings.split(',');
	mx=parseFloat(magRaw[1]);
	my=parseFloat(magRaw[2]);
	mz=parseFloat(magRaw[3]);
	
	document.getElementById("MagV").style.transform = myTranslate+" rotateX("+gyn+"deg) rotateY("+0+"deg) rotateZ("+gxn+"deg)";
	updatePlot(magP,magArray,mx,my,mz,mag_options,msamples);
}

function getPitch(kx,ky,kz)
{
	return 180*Math.atan2(kx,Math.sqrt(Math.pow(ky,2)+Math.pow(az,2)))/Math.PI;
	//return 180*Math.atan2(ax,Math.sqrt(Math.pow(ay,2)+Math.pow(az,2)))/Math.PI;
} 

function getRoll(kx,ky,kz)
{
	return 180*Math.atan2(-ky,kz)/Math.PI;
	//return 180*Math.atan2(ay,Math.sqrt(Math.pow(ax,2)+Math.pow(az,2)))/Math.PI;
}

function onSend(sendInfo)
{
	//console.log(sendInfo);
}

function onClose(result)
{
	
}

$('#connect').click(function(){
	var ConnectString = document.getElementById("portPath").value;
	
	var connectState = document.getElementById("connect").innerHTML;
	if(connectState=="Connect")
	{
		console.log("Connecting to "+ConnectString);
		_options.bitrate=parseInt(baudRates.value);
		chrome.serial.connect(ConnectString,_options,onConnect);
	}
	else
	{
		document.getElementById("connect").innerHTML="Connect";
		chrome.serial.onReceive.removeListener(getData);
		chrome.serial.disconnect(ConnectionData.connectionId, onClose);
		isConnected = false;
	}
});


function getSerialConnections(connections)
{
	//console.log(connections);
}

var RecievedData="";
var accTimer

$('#sendData').click(function(){
	var startState = document.getElementById("sendData").innerHTML;
	if(startState=="Start Timer")
	{
		document.getElementById("sendData").innerHTML="Stop Timer";
		accTimer = window.setInterval(checkAcc,25);
	}
	else
	{
		document.getElementById("sendData").innerHTML="Start Timer";
		window.clearInterval(accTimer);
	}
});


var local_test = 0

function checkAcc()
{
	checkvar =local_test%3; 
	if(checkvar==0)
	{
		chrome.serial.send(ConnectionData.connectionId,str2ab("GET_ACC\r"),onSend);
		samples++;
	}
	else if(checkvar==1)
	{
		chrome.serial.send(ConnectionData.connectionId,str2ab("GET_GYRO\r"),onSend);
		gsamples++;
	}
	else if(checkvar==2)
	{
		chrome.serial.send(ConnectionData.connectionId,str2ab("GET_MAG\r"),onSend);
		msamples++;
	}
	local_test++;
}

var lastCharPressed="";

$(document).keypress(function(event){
    lastCharPressed =String.fromCharCode(event.which); 
 })

$('#textBox').on('input', function(){
	var inputString = textBox.value; 
	var inputStringLength = textBox.value.length;
	var bufferLength = RecievedData.length;
	var sendString = lastCharPressed; 
	if(isConnected)
	{
		if(serialLogging)
		{
			console.log("Sending: " + sendString);
			$("#textBox").val(RecievedData);
			chrome.serial.send(ConnectionData.connectionId,str2ab(sendString),onSend);
			console.log("Removed Typed Data");
		}
	}
	else
	{
		$("#textBox").val('');
	}

});




