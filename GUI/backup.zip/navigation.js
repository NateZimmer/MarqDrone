function handleNavClick(thisItem,thisControl)
{
    if($(thisControl).css("display")=='none')
    {	
        $(thisControl).css("display","block");
        $(thisItem).css("backgroundColor","#fbac3a");
        $(thisItem).css("color","#000");
    }
    else
    {
        $(thisControl).css("display","none");
        $(thisItem).css("backgroundColor","#555");
        $(thisItem).css("color","#FFF");
    }
}

$('#Console').click(function(){
    handleNavClick(this,"#serialComs");
});

$('#Counter').click(function(){
    handleNavClick(this,"#jPractice");
});

$('#CubeB').click(function(){
    handleNavClick(this,"#FullCube");
});

$('#AccPlotB').click(function(){
    handleNavClick(this,"#AccPlot");
});

$('#AccCubeB').click(function(){
    handleNavClick(this,"#AccCube");
});

$('#GyroPlotB').click(function(){
    handleNavClick(this,"#GyroPlot");
});

$('#GyroCubeB').click(function(){
    handleNavClick(this,"#GyroCube");
});

$('#MagCubeB').click(function(){
    handleNavClick(this,"#MagCube");
});

$('#MagPlotB').click(function(){
    handleNavClick(this,"#MagPlot");
});

handleNavClick('#AccCubeB',"#AccCube");
handleNavClick('#AccPlotB',"#AccPlot");handleNavClick('#AccPlotB',"#AccPlot");
handleNavClick('#GyroCubeB',"#GyroCube");
handleNavClick('#GyroPlotB',"#GyroPlot");handleNavClick('#GyroPlotB',"#GyroPlot");
handleNavClick('#MagCubeB',"#MagCube");
handleNavClick('#MagPlotB',"#MagPlot");handleNavClick('#MagPlotB',"#MagPlot");
